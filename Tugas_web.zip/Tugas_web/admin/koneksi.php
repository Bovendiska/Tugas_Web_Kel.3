<?php
$con = new mysqli("localhost", "root", "","toko_online");

// Check connection
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}
echo "";
?>