
<?php 
    require "admin/koneksi.php";

    $queryproduk = mysqli_query($con,"SELECT id, nama, harga, foto, detail FROM produk LIMIT 4");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Online | Home </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require "navbar.php";?>
    
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container text-center text-white">
            <h1>Katalog Online</h1>
            <h4>Silahkan Dilihat Produk yang anda cari</h4>
            <form method="get" action="produk.php">
                    <div class="input-group input-group-lg my-4">
                    <input type="text" class="form-control" placeholder="Cari apa?" name="keyword"
                    aria-label="Cari apa?" aria-describedby="basic-addon2">
                    <button type="submit" class="btn warna4">Search</button>
                    </div>
            </form
         </div>
    </div>
</div>

    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3>Kategori Terlaris</h3>
            
            <div class="row mt-4">
                <div class="col-4"">
                <div class="highlighted-kategori kategori-earphone d-flex justify-content-center
                align-items-center">
                    <h4 class="text-white"><a class="no-decoration"href="produk.php?kategori=Earphone">Earphone</h4></a>
                </div>
                </div>
                <div class="col-4"">
                <div class="highlighted-kategori kategori-handphone  d-flex justify-content-center
                align-items-center">
                    <h4 class="text-white"><a class="no-decoration" href="produk.php?kategori=Handphone">Handphone</h4></a>
                </div>
                </div>
            </div>
        </div>
    </div>
   <!--Tentang kami -->

        <div class="container-fluid warna4 py-5">
            <div class="container text-center">
                <h3>Tentang Kami</h3>
                <p class="fs-5 mt-3">
                Toko kami sudah berdiri sejak tahun 2010, kami menjual barang elektronik dan membantu memilihkan barang yang sesuai dengan preferensi pembeli.

                Website kami berisi katalog untuk barang-barang yang kami jual di toko. Ketika pengguna datang ke toko kami, pengguna bisa login ke website kami dan melihat katalog produk yang tersedia di toko kami saat ini.
                Katalog online memberikan ruang untuk komunitas berbagi pengetahuan dan pengalaman, membantu pembeli membuat keputusan informasi yang lebih baik sebelum melakukan pembelian barang teknologi.

                Moto dari toko kami adalah pelanggan puas kami senang.
                Visi toko kami adalah untuk menjadi toko paling lengkap untuk barang elektronik.
                </p>
            </div>
        </div>

    <!--Produk -->

    <div class="container-fluid py-5">
        <div class="container">
            <h3>Produk</h3>
            <div class="row mt-5">
                <?php while($data = mysqli_fetch_array($queryproduk)){?>
                <div class="col-md-4">
                        <div class="card h-100">
                            <div class="image-box">
                                <img src="image/<?php echo $data['foto']?>" class="card-img-top" alt="...">
                            </div>
                        
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data['nama']?></h5>
                                <p class="card-text text-truncate"><?php echo $data['detail']?></p>
                                <p class="card-text text-harga">Rp.<?php echo $data['harga']?></p>
                                <a href="produk-detail.php?nama=<?php echo $data['nama']?>" class="btn btn-primary">Detail Produk</a>
                            </div>
                        </div>
                </div>
                <?php }?>
            </div>
        </div>
    </div>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>