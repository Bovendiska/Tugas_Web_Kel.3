<?php 
    require "admin/koneksi.php";

    $querykategori = mysqli_query($con,"SELECT * FROM kategori");

    if(isset($_GET['keyword'])){
        $keyword = mysqli_real_escape_string($con, $_GET['keyword']);
        $queryproduk = mysqli_query($con,"SELECT * FROM produk WHERE nama LIKE '%$keyword%'");
    }

    else if(isset($_GET['kategori'])){
        $kategori = mysqli_real_escape_string($con, $_GET['kategori']);
        $querykategoriid = mysqli_query($con,"SELECT id FROM kategori WHERE nama = '$kategori'");
        $kategoriid = mysqli_fetch_array($querykategoriid);

        $queryproduk = mysqli_query($con,"SELECT * FROM produk WHERE kategori_id = '$kategoriid[id]'");
    }
    else{
        $queryproduk = mysqli_query($con,"SELECT * FROM produk");
    }

    $countdata = mysqli_num_rows($queryproduk);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Online | Home </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require "navbar.php"?>

    <div class="container-fluid banner-produk d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">Produk</h1>
        </div>
    </div>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-3 mb-5"">
                <h3 class="text-center mt-3">Kategori</h3>
                <ul class="list-group">
                    <?php while($kategori = mysqli_fetch_array($querykategori)){;?>
                    <a class="no-decoration"href="produk.php?kategori=<?php echo $kategori['nama']?>">    
                    <li class="list-group-item"><?php echo $kategori['nama']?></li>
                    </a>
                    <?php }?>
                </ul>
            </div>
            <div class="col-lg-9"">
                    <h3 class="text-center mb-5">Produk</h3>
                    <div class="row">
                        <?php 
                            if($countdata<1){
                        ?>
                            <h4 class="text-center">Produk yang Anda cari tidak tersedia</h4>
                        <?php
                            }
                        ?>
                        <?php while($produk = mysqli_fetch_array($queryproduk)){?>
                        <div class="col-md-3">
                        <div class="card h-100">
                            <div class="image-box">
                                <img src="image/<?php echo $produk['foto']?>" class="card-img-top" alt="...">
                            </div>
                        
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $produk['nama']?></h5>
                                <p class="card-text text-truncate"><?php echo $produk['detail']?></p>
                                <p class="card-text text-harga">Rp.<?php echo $produk['harga']?></p>
                                <a href="produk-detail.php?nama=<?php echo urlencode($produk['nama'])?>" class="btn btn-primary">Detail Produk</a>
                            </div>
                        </div>
                        </div>
                        <?php }?>
                    </div>
                </div>
            
        </div>
    </div>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>